const Discord = require('discord.js');
const config = require('../config.json');

module.exports = {
    name: 'buttons',
    async execute(interaction) {
        if (interaction.isButton() && interaction.customId === "entrega"){
            const embed = new Discord.EmbedBuilder()
            .setTitle("<a:gw_engrenagem:1124475573511651398> Tópico Entrega")
            .setDescription(`Após o pagamento, nós entregamos o produto automaticamente ou manualmente sempre em perfeitas condições e estado, não há motivo de reclamações na entrega`)
            .setColor("#FF0000");
            const embed2 = new Discord.EmbedBuilder()
            .setTitle("<a:gw_engrenagem:1124475573511651398> Pós-Entrega")
            .setDescription(`Após o recebimento do produto pelo cliente, o produto não está mais em nossa responsabilidade e cuidados, então fique ciente com suas ações com o produto`)
            .setColor("#FF0000");


            await interaction.reply({ embeds: [embed, embed2], ephemeral: true})
        }
        if (interaction.isButton() && interaction.customId === "reembolso"){

            const embed = new Discord.EmbedBuilder()
            .setTitle("<a:gw_engrenagem:1124475573511651398> Tópico Reembolso")
            .setDescription(`Uma vez que o produto é entregue, após isso não estamos mais nos responsabilizando. Caso compre e venha querer o dinheiro de volta, não iremos dar prosseguimento a ação, então pense bem antes de comprar`)
            .setColor("#FF0000");


            await interaction.reply({ embeds: [embed], ephemeral: true})
        }
        if (interaction.isButton() && interaction.customId === "funcionarios"){
            const embed = new Discord.EmbedBuilder()
            .setTitle("<a:gw_engrenagem:1124475573511651398> Tópico Funcionários")
            .setDescription(`As vendas das pessoas com a tag "Vendedor" não fazem parte da equipe oficial da ! Vinx Community , são pessoas que pagaram ou que efetuaram um troca de tag entre lojas, caso vá comprar com alguém com essa tag, desconfie e peça intermédio`)
            .setColor("#FF0000");


            await interaction.reply({ embeds: [embed], ephemeral: true})
        }
        if (interaction.isButton() && interaction.customId === "plagio"){
            const embed = new Discord.EmbedBuilder()
            .setTitle("<a:gw_engrenagem:1124475573511651398> Plágio/Revenda")
            .setDescription(`Caso pegarmos alguma loja vendendo nosso curso, cx2 de bin entre outros, nós iremos cobrar que você divulgue a loja com everyone para nos dar o crédito.`)
            .setColor("#FF0000");


            await interaction.reply({ embeds: [embed], ephemeral: true})
        }
        if (interaction.isButton() && interaction.customId === "aceitaçao"){
            const embed = new Discord.EmbedBuilder()
            .setTitle("<a:gw_engrenagem:1124475573511651398> Tópico Aceitação")
            .setDescription(`Ao realizar a ação de compra no servidor, ou com algum dono, você aceita estes termos automaticamente sem direito a discussão`)
            .setColor("#FF0000");


            await interaction.reply({ embeds: [embed], ephemeral: true})
        }
        if (interaction.isButton() && interaction.customId === "garantia"){
            const embed = new Discord.EmbedBuilder()
            .setTitle("<a:gw_engrenagem:1124475573511651398> Tópico Entrega")
            .setDescription(`Antes de comprar, verifique se o produto tem garantia, pois não faremos a devolução do mesmo se cair, então por favor, fique ciente`)
            .setColor("#FF0000");


            await interaction.reply({ embeds: [embed], ephemeral: true})
        }
        if (interaction.isButton() && interaction.customId === "regras"){

            const embed = new Discord.EmbedBuilder()
            .setTitle("<a:gw_engrenagem:1124475573511651398> Nossas Regras")
            .setDescription(`1. Não spamme/flood o chat. \n2. Não divulgue vendas, exemplos "Vendo Bla Bla Bla" "Compro Bla Bla Bla" \n3. Não desrespeite nenhum membro. \n4. Não divulgue conteúdos,links e "métodos" suspeitos. \n5.Não divulgue servidores de terceiros.`)
            .setColor("#FF0000");


            interaction.reply({ embeds: [embed], ephemeral: true})
        }
    }}