const Discord = require("discord.js")

module.exports = {
    name: "ajuda",
    description: " Comando para veres o comando do bot",
    type: Discord.ApplicationCommandType.ChatInput,

    run: async (client, interaction, args) => {

        const embedajuda = new Discord.EmbedBuilder()
        .setTitle("**Lista de ajuda**")
        .setDescription(`***Veja minha lista de comandos, atualmente estou com 30 Comandos***`)
        .setColor(`Random`)
        .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
        .setThumbnail(interaction.guild.iconURL({ dynamic: true }))

        const b = new Discord.ButtonBuilder()
        .setLabel('Comandos Moder')
        .setEmoji("<a<:ray:1454947521855225950>1124475407106855014>")
        .setStyle("Primary")
        .setCustomId('fun')

        const b1 = new Discord.ButtonBuilder()
        .setLabel('Comandos Sistemas')
        .setEmoji("<a<:ray:1454947521855225950>1124475407106855014>")
        .setStyle("Primary")
        .setCustomId('adm')

        const b3 = new Discord.ButtonBuilder()
        .setLabel("Comandos Utilidades")
        .setEmoji("<a<:ray:1454947521855225950>1124475407106855014>")
        .setStyle("Primary")
        .setCustomId("music")

        const ac = new Discord.ActionRowBuilder()
        .addComponents(b, b1, b3)

        const aa = await interaction.reply({embeds: [embedajuda], components: [ac], ephemeral: true})

        const ccl = aa.createMessageComponentCollector()
        ccl.on('collect', async(help) => {

            if(help.customId === "fun") {

                const fun = new Discord.EmbedBuilder()
                .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
                .setDescription("***Veja meus comandos abaixo:***")
                .setColor("Random")
                .addFields(
                    {name: "/add_cargo", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Adiciona um cargo a um membro"}
                )
                .addFields(
                    {name: "/remove_cargo", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Remove um cargo de um membro"}
                )
                .addFields(
                    {name: "/ban", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Bane um usuario do servidor"}
                )
                .addFields(
                    {name: "/unban", value: "<a<:ray:1454947521855225950>1124475407106855014>>  |  Desbane um usuario do servidor"}
                )
                .addFields(
                    {name: "/clear", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Apaga mensagens do servidor"}
                )
                .addFields(
                    {name: "/lock", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Bloqueia um canal"}
                )
                .addFields(
                    {name: "/unlock", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Desbloqueia um canal"}
                )
                .addFields(
                    {name: "/mute", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Muta um usuario de falar no servidor"}
                )
                .addFields(
                    {name: "/unmute", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Desmuta um usuario de falar no servidor"}
                )
                .addFields(
                    {name: "/slowmode", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Configura o tempo de falar em um canal"}
                )
                .addFields(
                    {name: "/kick", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Expulse um membro do servidor"}
                )
                .addFields(
                    {name: "/criar_canal", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Crie um canal de voz/chat"}
                )
                .addFields(
                    {name: "/deletar_canal", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Deleta um chat"}
                )
                .addFields(
                    {name: "/renomear_canal", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Renomeie um canal"}
                )
                .addFields(
                    {name: "/clonar_canal", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Clone um canal"}
                )

                
                help.reply({embeds: [fun], ephemeral: true})
            }

            if(help.customId === "adm") {

                const adm = new Discord.EmbedBuilder()
                .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
                .setDescription("***Veja meus comandos abaixo:***")
                .setColor("Random")
                .addFields(
                    {name: "/connect", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Conecta o bot numa call"}
                )
                .addFields(
                    {name: "/botconfig", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Muda a configuração do bot"}
                )
                .addFields(
                    {name: "/invites", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Veja os invites de um usuario"}
                )
                .addFields(
                    {name: "/painel_avaliação", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Manda um painel de avaliação por modal"}
                )
                .addFields(
                    {name: "/painel_verificação", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Manda um painel de verificação por botão para receber cargo"}
                )
                .addFields(
                    {name: "/pcriar_webhook", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Crie um webhook"}
                )
                .addFields(
                    {name: "/painel_bater_ponto", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Manda um painel de bater ponto para staffs"}
                )
                .addFields(
                    {name: "/painel_cargo", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Manda um painel para dar cargo por botão para receber cargo"}
                )
                .addFields(
                    {name: "/terms", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  cria um painel sobre termos/regras e etc"}
                )
                .addFields(
                    {name: "/painel-sugestao", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  cria um painel de sugestão"}
                )

                
                help.reply({embeds: [adm], ephemeral: true})
            }

            if(help.customId === "music") {

                const music = new Discord.EmbedBuilder()
                .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
                .setDescription("***Veja meus comandos abaixo:***")
                .setColor("Random")
                .addFields(
                    {name: "/ajuda", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Este comando exibe os comandos do bot"}
                )
                .addFields(
                    {name: "/dm", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Manda uma mensagem na dm de um membro do servidor"}
                )
                .addFields(
                    {name: "/setstatus", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Muda o status do bot"}
                )
                .addFields(
                    {name: "/setnick", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Muda o nick de um membro do servidor"}
                )
                .addFields(
                    {name: "/renomear_server", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Mostra a lista de banidos do servidor"}
                )
                .addFields(
                    {name: "/embed", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Cria uma embed, tipo o /anunciar"}
                )
                .addFields(
                    {name: "/say", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Faz o bot te imitar"}
                )
                .addFields(
                    {name: "/ping", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Mostra o ping do bot"}
                )
                .addFields(
                    {name: "/lista_banidos_id", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Mostra a lista de ID dos banidos do servidor"}
                )
                .addFields(
                    {name: "/lista_banidos_tag", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Mostra a lista de nick dos banidos do servidor"}
                )
                .addFields(
                    {name: "/sorteio", value: "<a<:ray:1454947521855225950>1124475407106855014>  |  Crie um sorteio"}
                )
                
                help.reply({embeds: [music], ephemeral: true})
            }

        })
        
    }
}