
const Discord = require('discord.js');
const { QuickDB } = require("quick.db");
const db = new QuickDB({ table: "sugestao" });


module.exports = {
    name: "sugestao",
    description: "mande algo",
    type: 1,
    options:[
        {
            name: "mensagem",
            description: "escreva sua sugestao",
            type: Discord.ApplicationCommandOptionType.String,
            required: true,
        }],
    permissions: {},
    run: async (client, interaction, args) => {

       const sugestaomsg = interaction.options.getString("mensagem")

        const canal = await db.get(`canal_sugestao_${interaction.guild.id}`)

        let embed = new Discord.EmbedBuilder()
        .setAuthor({ name: `${interaction.guild} | Sugestão`, iconURL: interaction.guild.iconURL() })
        .setDescription(`> Nova sugestão fornecida!\n
        **Observações:**
> È apenas um voto por membro:`)
.addFields({
    name: `Usuário:`,
    value: `${interaction.user.username} \`(${interaction.user.id})\``,
    inline: false
},
{
    name: `Sugestão:`,
    value: `\`\`\`${sugestaomsg}\`\`\``,
    inline: false
})
        .setFooter({ text: `${interaction.user.username}`, iconURL: `${interaction.client.user.displayAvatarURL({ display: true, size: 4096 })}` })
        .setTimestamp()

        const botaoPositivo = new Discord.ButtonBuilder()
        .setLabel(`0`)
        .setCustomId("sim")
        .setEmoji("1138219908610662540")
        .setStyle(2)
        .setDisabled(false);
        
        const botaoNegativo = new Discord.ButtonBuilder()
        .setLabel(`0`)
        .setCustomId("nao")
        .setEmoji("1138219921998876682")
        .setStyle(2)
        .setDisabled(false);
    
        const botaoFinalizar = new Discord.ButtonBuilder()
        .setLabel(`Finalizar`)
        .setCustomId("sfinalizar")
        .setStyle(1)
        .setDisabled(false);
    
    const row1 = new Discord.ActionRowBuilder()
    .addComponents(botaoPositivo, botaoNegativo, botaoFinalizar);


        await interaction.reply({content: `Sugestão enviada com sucesso`, ephemeral: true})

        const msg =  await client.channels.cache.get(canal).send({embeds: [embed], components: [row1]})

        await db.set(msg.id, {
            sugestao: sugestaomsg,
            usuario: interaction.user.id,
            positivo: 0,
            negativo: 0,
            total: []
        });

 


    }
}
