const Discord = require("discord.js");

module.exports = {
  name: "renomear_server",
  description: "🛠️ Renomear o servidor",
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
      name: "nome",
      description: "Digite um novo nome para o servidor",
      type: Discord.ApplicationCommandOptionType.String,
      required: true,
    },
  ],

  run: async (client, interaction, args) => {
    const Newname = interaction.options.getString("nome");
    const Oldname = interaction.guild.name;
    if (!interaction.member.permissions.has(Discord.PermissionFlagsBits.ManageGuild)) {
      interaction.reply({
        content: `Você não possui permissão para utilizar este comando.`,
        ephemeral: true,
      });
    } else {
      let embed = new Discord.EmbedBuilder()
        .setTitle("Servidor Renomeado!")
        .setColor("#8C9FFF")
        .setThumbnail(interaction.guild.iconURL())
        .setTimestamp()
        .addFields(
          { name: `<:ID:1121658458329075833> | Nome Antigo:`, value: `> ${Oldname}`, inline: true },
          { name: `<:ID:1121658458329075833> | Novo Nome:`, value: `> ${Newname}`, inline: true })
      interaction.guild
        .setName(Newname)
        .then(() => {
          interaction.reply({ embeds: [embed] });
        })
        .catch((err) => {
          console.log(err);
          interaction.reply({
            content: "Ocorreu um erro ao renomear o servidor.",
            ephemeral: true,
          });
        });
    }
  },
};