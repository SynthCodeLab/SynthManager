const Discord = require('discord.js')
const config = require('../../config.json')

module.exports = {
    name: 'botconfig',
    description: '🛠️ Gerenciar seu bot',

    run: async (client, interaction) => {

        if (interaction.user.id != config.dono_bot) { // colocar o id de quem vai ter a perm.
            return interaction.reply({
                embeds: [
                    new Discord.EmbedBuilder()
                        .setDescription(`**${interaction.user.tag}**, Você não tem permissão para usar este comando.`)
                        .setColor("#006df0")
                        .setTimestamp()
                ],
                ephemeral: true,
            })
        } else {

            interaction.reply({
                components: [
                    new Discord.ActionRowBuilder()
                        .addComponents(
                            new Discord.ButtonBuilder()
                                .setCustomId("alterar_username")
                                .setLabel("Alterar Nome do Bot")
                                .setEmoji("<a:EngrenagemAKStore:1124475559334907944>")
                                .setStyle(Discord.ButtonStyle.Secondary),
                            new Discord.ButtonBuilder()
                                .setCustomId("alterar_avatar")
                                .setLabel("Alterar Avatar do Bot")
                                .setEmoji("<a:EngrenagemAKStore:1124475559334907944>")
                                .setStyle(Discord.ButtonStyle.Secondary),
                        )
                ],
                embeds: [
                    new Discord.EmbedBuilder()
                        .setTitle(`**Painel de Configuração do Bot**`)
                        .setDescription(` \`\`\`
Painel para mudar meu perfil:

Botão de Mudar Avatar do Bot, para mudar o avatar do seu bot usando o URL do avatar em um modal.

Botão de mudar o Nome do Bot, para mudar o nome do seu bot em um modal.
\`\`\`
[Clique aqui](https://discord.com/oauth2/authorize?client_id=${client.user.id}&scope=bot&permissions=0) **para pegar meu invite.**`)
                        .setColor("Blue")
                        .setTimestamp()
                        .setFooter({ text: client.user.username, iconURL: client.user.displayAvatarURL({ dinamyc: true }) })
                ],
                ephemeral: true,
            })
        }
    }
}