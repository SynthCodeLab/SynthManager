const Discord = require('discord.js');
const { QuickDB } = require("quick.db");
const db = new QuickDB({ table: "sugestao" });


module.exports = {
    name: "painel-sugestao",
    description: "mande algo",
    type: 1,
    options: [
        {
            name: "canal_sugestao",
            description: "configure o canal aonde será enviado as sugestão",
            type: Discord.ApplicationCommandOptionType.Channel,
            required: true
        },
        {
            name: "cargo_staff",
            description: "configure o cargo staff",
            type: Discord.ApplicationCommandOptionType.Role,
            required: true
        },
        {
            name: "canal_logs",
            description: "configure o canal de logs",
            type: Discord.ApplicationCommandOptionType.Channel,
            required: true
        },

    ],
    permissions: {},
    run: async (client, interaction, args) => {


        const canal = interaction.options.getChannel("canal_sugestao");
        const cargo_staff = interaction.options.getRole("cargo_staff");
        const canallogs = interaction.options.getChannel("canal_logs");


        let painel = new Discord.EmbedBuilder()
        .setDescription(`Configurando, aguarde...`)
        const reply = await interaction.reply({embeds: [painel]})

        const deletarmsg = async (message, timeout) => {
            setTimeout(() => {
                message.delete().catch(console.error);
            }, timeout);
        };

        if (canal.type !== Discord.ChannelType.GuildText) {

            let painel2 = new Discord.EmbedBuilder()
            .setDescription(`o canal \`${canal.name}\`não é um canal de texto`)
           const msg2 = await interaction.channel.send({ embeds: [painel2], ephemeral: true })
           deletarmsg(msg2, 4000);

        } else {
            let painel3 = new Discord.EmbedBuilder()
            .setDescription(`o canal de texto ${canal} foi configurado com sucesso.`)
            
         const msg3 = await interaction.channel.send({ embeds: [painel3], ephemeral: true })
           await db.set(`canal_sugestao_${interaction.guild.id}`, canal.id)

           deletarmsg(msg3, 4000);
    
        }
        if (canallogs.type !== Discord.ChannelType.GuildText) {

            let painel4 = new Discord.EmbedBuilder()
            .setDescription(`o canal de texto \`${canallogs.name}\` não é um canal de texto.`)
           const msg4 =  await interaction.channel.send({ embeds:  [painel4], ephemeral: true })
           deletarmsg(msg4, 4000);
        } else {

            let painel5 = new Discord.EmbedBuilder()
            .setDescription(`o canal de texto ${canallogs} foi configurado com sucesso.`)

            const msg5 = await interaction.channel.send({ embeds: [painel5] })
                await db.set(`canal_logs_${interaction.guild.id}`, canallogs.id)

      deletarmsg(msg5, 4000);
          
        }
        let painel6 = new Discord.EmbedBuilder()
        .setDescription(`o cargo \`${cargo_staff.name}\` foi configurado com sucesso.`)

        const msg6 = await interaction.channel.send({ embeds: [painel6] })

            await db.set(`cargo_staff_${interaction.guild.id}`, cargo_staff.id)

            deletarmsg(msg6, 4000);
        
        setTimeout(async () => {
            
        let result = new Discord.EmbedBuilder()
        .setAuthor({ name: `${interaction.guild} | Configurado com sucesso`, iconURL: interaction.guild.iconURL() })
        .setDescription(`Cargo atual: ${canal}\nCargo Staff: ${cargo_staff}\nLogs: ${canallogs}`)
        .setTimestamp()

        await reply.edit({embeds: [result]})

    }, 2000);
    }
} 
