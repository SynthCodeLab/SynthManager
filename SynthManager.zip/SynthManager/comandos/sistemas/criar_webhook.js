const Discord = require("discord.js");

const moment = require("moment");
moment.locale("pt-br");

module.exports = {
    name: "criar_webhook",
    description: "🛠️ Crie uma Webhook",
    options: [
        {
            name: `canal`,
            type: Discord.ApplicationCommandOptionType.Channel,
            description: 'Canal que será criado o Webhook',
            required: true,
            channelTypes: [0]
        },
        {
            name: `nome`,
            type: Discord.ApplicationCommandOptionType.String,
            description: 'Nome da Webhook',
            required: false,
            maxLength: 30
        }
    ],
    type: Discord.ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {

        if (!interaction.member.permissions.has(Discord.PermissionFlagsBits.Administrator)) {
            return interaction.reply({
                content: `<a:errado_start_community:1121635302230990919> | ${interaction.user}, Você não tem permissões suficiente para usar este comando!`
            });

        } else {

            const channelW = interaction.options.getChannel('canal');
            const nameW = interaction.options.getString('nome') || `${interaction.user.tag} - ${moment().format(`DD/MM/YYYY`)}`;

            try {

                // Cria a webhook
                const webhook = await channelW.createWebhook({
                    name: nameW,
                    reason: `WebHook criada por ${interaction.user.username}`
                });
                await interaction.reply({
                    content: `<a:1111104374039662704:1124475416707616828> | ${interaction.user}, WebHook criada no canal ${channelW} com sucesso. [WebHook Aqui](${webhook.url})\n\n⚠ | Por questões de **segurança** está mensagem foi enviada em **ephemeral.**`,
                    ephemeral: true
                });

            } catch (error) {

                // Bot Sem permissão suficiente ou algum outro erro
                console.log(error);
                return interaction.reply({
                    content: `<a:policia_SPACE1:1121658493779325069> | ${interaction.user}, Ocorreu um erro desconhecido ao criar uma webhook no canal ${channelW}.`
                });

            };

        };
    }
}