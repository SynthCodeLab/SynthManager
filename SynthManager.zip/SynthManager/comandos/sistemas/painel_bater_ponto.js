const Discord = require("discord.js")
const dc = require('discord.js');
const moment = require("moment");
const { set } = require("mongoose");

module.exports = {
  name: "painel_bater_ponto",
  description: "🛠️ Ativar painel de bater ponto.",
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
        name: 'canal',
        description: 'Selecione um canal de texto.',
        type: Discord.ApplicationCommandOptionType.Channel,
        required: true,
    },
    {
      name: "cargo_staff",
      description: "Mencione o cargo staff para bater ponto.",
      type: Discord.ApplicationCommandOptionType.Role,
      required: true,
  }
  ],

  run: async (client, interaction) => {

    if (!interaction.member.permissions.has(Discord.PermissionFlagsBits.Administrator))
    return interaction.reply({
        content: `Ops ${interaction.user}, você não possui permissão para utilizar este comando!`,
        ephemeral: true,
    })

    interaction.reply({ content: `Painel bate-ponto enviado com sucesso!`, ephemeral: true })

        const role = interaction.options.getRole("cargo_staff") 
        const canalEnv = interaction.options.getChannel("canal")

    const embedT = new Discord.EmbedBuilder()
    .setTitle(`**Bater Ponto | Vinx Community**`)
    .setThumbnail(interaction.guild.iconURL({ dinamyc: true, format: "png", size: 4096 }))
    .setDescription(`
**Para abrir seu ponto, clique no botao "<a:1111104374039662704:1124475416707616828>".
    
Para fechar seu ponto, clique no botao "<a:errado1:1124475561545318462>".**`)
    .setColor('Green')
    .setFooter({
        iconURL: interaction.guild.iconURL({ dynamic: true }),
        text: (`Copyright © |white.hats`)
            })
    .setTimestamp()

    const acct = new dc.ActionRowBuilder()
                  .addComponents(
                  new dc.ButtonBuilder()
                  .setLabel("Abrir Ponto")
                  .setStyle(2)
                  .setCustomId("btE")
                  .setEmoji("<a:1111104374039662704:1124475416707616828>"),
                  new dc.ButtonBuilder()
                  .setLabel("Fechar Ponto")
                  .setStyle(2)
                  .setCustomId("btS")
                  .setEmoji(`<a:errado_start_community:1121635302230990919>`),
                  )

    canalEnv.send({ embeds: [embedT], components: [acct] })
    
    
  }}
