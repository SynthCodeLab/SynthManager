const Discord = require("discord.js")

module.exports = {

  name: "terms", // Coloque o nome do comando

  description: "uma base para se usar embed", // Coloque a descrição do comand
  options: [
    {
        name: "canal",
        description: "qual canal será enviado?",
        type: Discord.ApplicationCommandOptionType.Channel,
        required: true,
    }],



  run: async (client, interaction) => {


    if (!interaction.member.permissions.has(Discord.PermissionFlagsBits.ManageGuild)) {
        interaction.reply({ content: `Você não possui permissão para utilizar este comando.`, ephemeral: true })
    }else {
        let channel = interaction.options.getChannel("canal")
const exampleEmbed = new Discord.EmbedBuilder()
	.setColor("#FF0000")
	.setTitle('Seja Bem-Vindo a ')
	.setDescription('Para evitarmos textos grandes, separamos em botões para facilitar \n\n**Saiba que é importante ler tudo para evitar qualquer tipo de problema.**')
	.setImage('https://media.discordapp.net/attachments/1042459360955207711/1116198139255324772/1_7090421f-73ba-46ac-8ff1-dd56f4386d9a.jpg?width=960&height=250') //coloque imagem do seu server
    const buttons = new Discord.ActionRowBuilder()
        .addComponents(
            new Discord.ButtonBuilder()
            .setCustomId('entrega')
            .setLabel('Entrega')
            .setStyle(1),
            )
        .addComponents(
                new Discord.ButtonBuilder()
                .setCustomId('reembolso')
                .setLabel('Reembolso')
                .setStyle(1))
        .addComponents(
                new Discord.ButtonBuilder()
                .setCustomId('funcionarios')
                .setLabel('Funcionários')
                .setStyle(1))

        .addComponents(
                new Discord.ButtonBuilder()
                .setCustomId('plagio')
                .setLabel('Plágio/Revenda')
                .setStyle(1))

        .addComponents(
            new Discord.ButtonBuilder()
                .setCustomId('aceitaçao')
                .setLabel('Aceitação')
                .setStyle(1));
    const buttons2 = new Discord.ActionRowBuilder()
    .addComponents(
        new Discord.ButtonBuilder()
        .setCustomId('garantia')
        .setLabel('Garantia')
        .setStyle(1)
    )
    .addComponents(
        new Discord.ButtonBuilder()
        .setCustomId('regras')
        .setLabel('Regras')
        .setStyle('1')
    )
            

await channel.send({ embeds: [exampleEmbed], components: [buttons, buttons2] })
interaction.reply ({content:"<a:emoji_82:1124475557409722408> Embed Enviada Com Sucesso", ephemeral: true})

}

}


  }
