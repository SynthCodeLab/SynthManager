const Discord = require("discord.js");

module.exports = {
    name: "clonar_canal",
    description: "🛠️ Clone um Canal!",
    options: [
        {
            name: `canal`,
            type: Discord.ApplicationCommandOptionType.Channel,
            description: 'Canal que será Clonado',
            required: true,
            channelTypes: [0, 2]
        }
    ],
    type: Discord.ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {

        if (!interaction.member.permissions.has(Discord.PermissionFlagsBits.Administrator)) {
            return interaction.reply({
                content: "<:A_avisoTKF:1121658366536728587> | Você não tem permissão para usar este comando!",
                ephemeral: true,
            });

        } else {

            const channel = interaction.options.getChannel('canal');

            try {

                // Clona o canal selecionado embaixo dele
                const newChannel = await channel.clone();
                await newChannel.setPosition(channel.position + 1);
                await newChannel.setName(`${channel.name}-2`)
                await interaction.reply({
                    content: `<a:1111104374039662704:1124475416707616828> | Canal clonado com sucesso. Novo canal: ${newChannel}`,
                    ephemeral: false,
                });

            } catch (error) {

                // Bot Sem permissão suficiente ou algum outro erro, adiciona "console.log(error)" se quiser
                return interaction.reply({
                    content: `<a:errado_start_community:1121635302230990919> | Ocorreu um erro desconhecido ao clonar o canal ${channel}.`,
                    ephemeral: true
                });

            };

        };
    }
}
